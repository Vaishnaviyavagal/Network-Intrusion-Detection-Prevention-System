# app.py — Object-Oriented NIDPS with Authentication + Working Live Capture
from flask import Flask, render_template, request, jsonify, send_file, session, redirect, url_for
import json, csv, io, os, sys, threading, subprocess, socket, time, hashlib, secrets
from datetime import datetime, date, timedelta
from collections import defaultdict
from typing import Optional

# ===== Live packet capture (Scapy) =====
try:
    from scapy.all import sniff, IP
    SCAPY_AVAILABLE = True
except Exception:
    SCAPY_AVAILABLE = False
    IP = None
    def sniff(*args, **kwargs):
        raise RuntimeError("Scapy is not available. Install scapy to enable packet capture.")

# ===== Optional ML model support (joblib/pandas) =====
try:
    from joblib import load as joblib_load
except Exception:
    joblib_load = None

try:
    import pandas as pd
except Exception:
    pd = None


class UserManager:
    """Manages user authentication and sessions"""
    
    def __init__(self, config):
        self.config = config
        self.users_file = "users.json"
        self.session_timeout = timedelta(hours=24)
        self.ensure_users_file()
    
    def ensure_users_file(self):
        """Create users file if it doesn't exist"""
        if not os.path.exists(self.users_file):
            with open(self.users_file, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)
    
    def hash_password(self, password: str) -> str:
        """Hash password with salt"""
        salt = secrets.token_hex(16)
        return hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000).hex() + ":" + salt
    
    def verify_password(self, stored_password: str, provided_password: str) -> bool:
        """Verify password against stored hash"""
        try:
            password_hash, salt = stored_password.split(":")
            return password_hash == hashlib.pbkdf2_hmac(
                'sha256', provided_password.encode(), salt.encode(), 100000
            ).hex()
        except:
            return False
    
    def create_user(self, username: str, password: str, email: str = "") -> dict:
        """Create new user"""
        users = self.load_users()
        
        # Check if username already exists
        if any(user['username'] == username for user in users):
            return {"success": False, "error": "Username already exists"}
        
        # Create user
        new_user = {
            "id": len(users) + 1,
            "username": username,
            "email": email,
            "password_hash": self.hash_password(password),
            "created_at": datetime.now().isoformat(),
            "last_login": None,
            "role": "user",
            "is_active": True
        }
        
        users.append(new_user)
        self.save_users(users)
        
        return {"success": True, "user": {"id": new_user["id"], "username": username}}
    
    def authenticate_user(self, username: str, password: str) -> dict:
        """Authenticate user"""
        users = self.load_users()
        
        for user in users:
            if user['username'] == username and user['is_active']:
                if self.verify_password(user['password_hash'], password):
                    # Update last login
                    user['last_login'] = datetime.now().isoformat()
                    self.save_users(users)
                    
                    return {
                        "success": True, 
                        "user": {
                            "id": user["id"],
                            "username": user["username"],
                            "role": user["role"]
                        }
                    }
        
        return {"success": False, "error": "Invalid username or password"}
    
    def load_users(self) -> list:
        """Load users from file"""
        try:
            with open(self.users_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return []
    
    def save_users(self, users: list):
        """Save users to file"""
        with open(self.users_file, "w", encoding="utf-8") as f:
            json.dump(users, f, indent=2)
    
    def get_user_by_id(self, user_id: int) -> Optional[dict]:
        """Get user by ID"""
        users = self.load_users()
        for user in users:
            if user['id'] == user_id:
                return user
        return None

class AuthMiddleware:
    """Handles authentication middleware"""
    
    def __init__(self, user_manager: UserManager):
        self.user_manager = user_manager
    
    def check_auth(self):
        """Check if user is authenticated"""
        if 'user_id' not in session:
            return False
        
        user = self.user_manager.get_user_by_id(session['user_id'])
        if not user or not user.get('is_active', True):
            session.clear()
            return False
        
        # Check session timeout
        last_activity = session.get('last_activity')
        if last_activity:
            last_activity_dt = datetime.fromisoformat(last_activity)
            if datetime.now() - last_activity_dt > self.user_manager.session_timeout:
                session.clear()
                return False
        
        # Update last activity
        session['last_activity'] = datetime.now().isoformat()
        return True
    
    def require_auth(self, f):
        """Decorator to require authentication"""
        def decorated_function(*args, **kwargs):
            if not self.check_auth():
                return redirect(url_for('login_page'))
            return f(*args, **kwargs)
        decorated_function.__name__ = f.__name__
        return decorated_function
    
    def require_unauth(self, f):
        """Decorator to require no authentication (for login/signup pages)"""
        def decorated_function(*args, **kwargs):
            if self.check_auth():
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        decorated_function.__name__ = f.__name__
        return decorated_function

class NIDPSConfig:
    """Configuration management for NIDPS"""
    def __init__(self):
        self.ROOT_LOG_DIR = "logs"
        os.makedirs(self.ROOT_LOG_DIR, exist_ok=True)
        
        self.MODEL_PATH = "ml_model.joblib"
        self.RULES_FILE = "rules.json"
        self.IDS_LOG_FILE = "logs.json"
        self.HONEYPOT_LOG = os.path.join(self.ROOT_LOG_DIR, "honeypot_log.json")
        self.BLACKLIST_FILE = "blacklist.json"
        
        # Ensure required files exist
        self.ensure_required_files()
    
    def ensure_required_files(self):
        """Create required files if they don't exist"""
        required_files = [
            self.RULES_FILE,
            self.IDS_LOG_FILE, 
            self.HONEYPOT_LOG,
            self.BLACKLIST_FILE
        ]
        
        for file_path in required_files:
            self.ensure_json_array(file_path)
    
    def ensure_json_array(self, path: str):
        """Create or repair a JSON array file."""
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as f:
                f.write("[]")
            return
        
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    raise json.JSONDecodeError("empty", "", 0)
                json.loads(content)
        except json.JSONDecodeError:
            with open(path, "w", encoding="utf-8") as f:
                f.write("[]")

class JSONManager:
    """Handles JSON file operations"""
    
    @staticmethod
    def load_json_array(path: str) -> list:
        """Load JSON array from file"""
        NIDPSConfig().ensure_json_array(path)
        try:
            with open(path, "r", encoding="utf-8") as f:
                arr = json.load(f)
                return arr if isinstance(arr, list) else []
        except Exception:
            return []
    
    @staticmethod
    def save_json_array(path: str, arr: list):
        """Save list to JSON file"""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(arr, f, indent=2)

class RuleManager:
    """Manages intrusion detection rules"""
    
    def __init__(self, config: NIDPSConfig):
        self.config = config
    
    def load_rules(self) -> list[dict]:
        """Load rules from JSON file"""
        return JSONManager.load_json_array(self.config.RULES_FILE)
    
    def save_rules(self, rules: list[dict]):
        """Save rules to JSON file"""
        JSONManager.save_json_array(self.config.RULES_FILE, rules)
    
    def add_rule(self, rule_data: dict) -> dict:
        """Add a new rule"""
        rules = self.load_rules()
        rules.append(rule_data)
        self.save_rules(rules)
        return {"status": "ok", "rule": rule_data}
    
    def delete_rule(self, index: int) -> dict:
        """Delete rule by index"""
        rules = self.load_rules()
        if not (0 <= index < len(rules)):
            return {"status": "error", "error": "index out of range"}
        
        removed = rules.pop(index)
        self.save_rules(rules)
        return {"status": "ok", "removed": removed}

class BlacklistManager:
    """Manages IP blacklist"""
    
    def __init__(self, config: NIDPSConfig):
        self.config = config
    
    def load_blacklist(self) -> set[str]:
        """Load blacklisted IPs"""
        try:
            if not os.path.exists(self.config.BLACKLIST_FILE):
                return set()
            with open(self.config.BLACKLIST_FILE, "r", encoding="utf-8") as f:
                return set(json.load(f))
        except Exception:
            return set()
    
    def save_blacklist(self, blacklist: set[str]):
        """Save blacklist to file"""
        with open(self.config.BLACKLIST_FILE, "w", encoding="utf-8") as f:
            json.dump(list(blacklist), f, indent=2)
    
    def add_to_blacklist(self, ip: str) -> dict:
        """Add IP to blacklist"""
        blacklist = self.load_blacklist()
        blacklist.add(ip)
        self.save_blacklist(blacklist)
        return {"status": f"{ip} blacklisted"}

class HoneypotManager:
    """Manages honeypot deployment and control"""
    
    def __init__(self, config: NIDPSConfig):
        self.config = config
        self.process = None
        self.status = {"running": False, "port": 9999}
    
    def _is_listening(self, host: str, port: int, timeout: float = 0.25) -> bool:
        """Check if a port is listening"""
        try:
            with socket.create_connection((host, int(port)), timeout=timeout):
                return True
        except Exception:
            return False
    
    def _is_port_available(self, port: int) -> bool:
        """Check if port is available for binding"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(('0.0.0.0', port))
                return True
        except OSError:
            return False
    
    def _honeypot_script(self) -> Optional[str]:
        """Find honeypot script"""
        for script_name in ["honeypot.py", "honey.py", "honeypot/honeypot.py"]:
            if os.path.exists(script_name):
                return script_name
        return None
    
    def start(self, port: int) -> dict:
        """Start honeypot process"""
        script = self._honeypot_script()
        if not script:
            return {"status": "error", "error": "Honeypot script not found"}, 500
        
        try:
            port = int(port)
        except (ValueError, TypeError):
            port = 9999
        
        # Check port availability
        if not self._is_port_available(port):
            return {"status": "error", "error": f"Port {port} is already in use"}, 500
        
        # Stop existing honeypot
        self.stop()
        
        self.status["port"] = port
        
        try:
            # Start honeypot with explicit log path
            log_path = os.path.abspath(self.config.HONEYPOT_LOG)
            self.process = subprocess.Popen(
                [sys.executable, script, str(port), log_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            print(f"[*] Started honeypot on port {port}, PID: {self.process.pid}")
            
        except Exception as e:
            return {"status": "error", "error": f"Failed to start honeypot: {str(e)}"}, 500
        
        # Wait for honeypot to start listening
        for i in range(50):
            time.sleep(0.1)
            if self._is_listening("127.0.0.1", port):
                self.status["running"] = True
                
                if self.process.poll() is not None:
                    stdout, stderr = self.process.communicate()
                    error_msg = stderr.decode('utf-8', errors='ignore') if stderr else "Unknown error"
                    return {"status": "error", "error": f"Honeypot crashed: {error_msg}"}, 500
                
                return {"status": "started", "port": port, "pid": self.process.pid}, 200
        
        self.stop()
        return {"status": "error", "error": "Honeypot failed to start listening within timeout"}, 500
    
    def stop(self) -> dict:
        """Stop honeypot process"""
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    self.process.kill()
                    self.process.wait(timeout=2)
                except:
                    pass
            except Exception:
                pass
            
            self.process = None
        
        self.status["running"] = False
        return {"status": "stopped"}, 200
    
    def get_status(self) -> dict:
        """Get honeypot status"""
        running = False
        listening = False
        pid = None
        
        if self.process is not None:
            if self.process.poll() is None:
                running = True
                pid = self.process.pid
                port = self.status.get("port", 9999)
                listening = self._is_listening("127.0.0.1", port)
                
                if not listening:
                    running = False
                    self.status["running"] = False
            else:
                self.process = None
                self.status["running"] = False
        
        return {
            "running": running,
            "listening": listening,
            "port": self.status.get("port", 9999),
            "pid": pid
        }
    
    def test_connection(self, port: int) -> dict:
        """Test honeypot connection"""
        if not self.status["running"]:
            return {"ok": False, "error": "Honeypot is not running", "port": port}, 500
        
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=2.0) as s:
                s.settimeout(2.0)
                
                # Try to receive banner
                try:
                    banner = s.recv(1024)
                    print(f"[*] Received banner: {banner[:100]}")
                except socket.timeout:
                    pass
                
                # Send test data
                test_data = b"GET /test HTTP/1.1\r\nHost: localhost\r\n\r\n"
                s.sendall(test_data)
                
                # Try to receive response
                try:
                    response = s.recv(1024)
                    print(f"[*] Received response: {response[:100]}")
                except socket.timeout:
                    pass
                    
            return {"ok": True, "port": port, "message": "Test connection successful"}
            
        except Exception as e:
            return {"ok": False, "error": str(e), "port": port}, 500

class HoneypotLogManager:
    """Manages honeypot log operations"""
    
    def __init__(self, config: NIDPSConfig):
        self.config = config
    
    def _normalize_hpot(self, entry: dict) -> dict:
        """Normalize honeypot log record"""
        if not isinstance(entry, dict):
            return {}
        
        out = dict(entry)
        if "ip" not in out and "source_ip" in out:
            out["ip"] = out.get("source_ip")
        if "request" not in out and "payload" in out:
            out["request"] = out.get("payload")
        
        out.setdefault("port", 9999)
        out.setdefault("alert", True)
        out.setdefault("source", "honeypot")
        
        return {
            "timestamp": out.get("timestamp"),
            "ip": out.get("ip"),
            "port": out.get("port"),
            "request": out.get("request"),
            "alert": out.get("alert"),
            "source": out.get("source"),
        }
    
    def read_logs(self) -> list[dict]:
        """Read honeypot logs"""
        arr = JSONManager.load_json_array(self.config.HONEYPOT_LOG)
        return [self._normalize_hpot(x) for x in arr]
    
    def _parse_date(self, date_str: Optional[str]) -> Optional[date]:
        """Parse date string"""
        if not date_str:
            return None
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
            try:
                return datetime.strptime(date_str, fmt).date()
            except Exception:
                pass
        return None
    
    def get_filtered_logs(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> dict:
        """Get filtered honeypot logs"""
        start = self._parse_date(start_date)
        end = self._parse_date(end_date)
        rows = self.read_logs()
        
        if start or end:
            filtered_rows = []
            for row in rows:
                try:
                    log_date = datetime.strptime(row["timestamp"], "%Y-%m-%d %H:%M:%S").date()
                except Exception:
                    continue
                
                if start and log_date < start:
                    continue
                if end and log_date > end:
                    continue
                filtered_rows.append(row)
            rows = filtered_rows
        
        # Include legacy keys for compatibility
        def add_legacy_keys(entry):
            return {**entry, "source_ip": entry["ip"], "payload": entry["request"]}
        
        return {"logs": [add_legacy_keys(x) for x in rows]}

class IDSLogManager:
    """Manages IDS log operations + Live Capture"""
    
    def __init__(self, config: NIDPSConfig):
        self.config = config
        self.packet_log = []
        self.ml_enabled = True
        self.sniffer_thread = None
        
        # Optional ML model loading
        self.model = None
        if joblib_load and pd and os.path.exists(self.config.MODEL_PATH):
            try:
                self.model = joblib_load(self.config.MODEL_PATH)
                print("[*] ML model loaded for IDS:", self.config.MODEL_PATH)
            except Exception as e:
                print("[!] Failed to load ML model:", e)
    
        # Start background sniffer automatically
        self.start_sniffer()
    
    # ---------- File-backed IDS logs ----------
    def load_logs(self) -> list[dict]:
        """Load IDS logs"""
        return JSONManager.load_json_array(self.config.IDS_LOG_FILE)
    
    def save_log(self, entry: dict):
        """Save IDS log entry (keep last 1000)"""
        logs = self.load_logs()
        logs.append(entry)
        JSONManager.save_json_array(self.config.IDS_LOG_FILE, logs[-1000:])
    
    # ---------- Stats ----------
    def get_stats(self) -> dict:
        """Get IDS statistics"""
        logs = self.load_logs()
        total = len(logs)
        rule_alerts = sum(1 for x in logs if x.get("type") == "rule")
        ml_alerts = sum(1 for x in logs if x.get("type") == "ml")
        safe = total - rule_alerts - ml_alerts
        
        return {
            "total": total,
            "rule": rule_alerts,
            "ml": ml_alerts,
            "safe": safe
        }
    
    def get_alerts_per_hour(self) -> dict:
        """Get alerts per hour statistics"""
        logs = self.load_logs()
        hourly = defaultdict(int)
        
        for log in logs:
            if log.get("alert"):
                try:
                    ts = datetime.strptime(log["timestamp"], "%Y-%m-%d %H:%M:%S")
                    hourly[ts.strftime("%Y-%m-%d %H:00")] += 1
                except Exception:
                    pass
        
        keys = sorted(hourly.keys())
        return {"labels": keys, "counts": [hourly[k] for k in keys]}
    
    # ---------- ML Scoring (optional) ----------
    def _model_predict(self, proto: int, length: int) -> float:
        """Return anomaly score in [0,1] using optional model; 0.0 if unavailable."""
        try:
            if not self.model or not pd:
                return 0.0
            X = pd.DataFrame([[proto, length]], columns=["proto", "length"])
            if hasattr(self.model, "predict_proba"):
                proba = self.model.predict_proba(X)
                return float(proba[0][1])
            y = self.model.predict(X)
            score = float(y[0])
            return 1.0 if score >= 1 else max(0.0, min(1.0, score))
        except Exception as e:
            print("[ML] predict error:", e)
            return 0.0
    
    # ---------- Live Capture ----------
    def packet_handler(self, pkt):
        """Handle captured packets: parse -> classify (ML/rule) -> buffer + persist"""
        try:
            if IP in pkt:
                src_ip = pkt[IP].src
                dst_ip = pkt[IP].dst
                proto = int(pkt[IP].proto)
                length = int(len(pkt))
                
                entry = {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "src": src_ip,
                    "dst": dst_ip,
                    "protocol": proto,
                    "payload_len": length,
                    "type": "safe",
                    "alert": False
                }
                
                if self.ml_enabled:
                    score = self._model_predict(proto, length)  # 0.0 if no model
                    if score >= 0.8:
                        entry["type"] = "ml"
                        entry["alert"] = True
                else:
                    # Rule-based detection
                    for rule in JSONManager.load_json_array(self.config.RULES_FILE):
                        r_src = (rule.get("src") or "").strip()
                        r_dst = (rule.get("dst") or "").strip()
                        r_proto = (rule.get("protocol") or "").strip()
                        
                        src_ok = (not r_src) or (r_src in src_ip)
                        dst_ok = (not r_dst) or (r_dst in dst_ip)
                        proto_ok = True
                        if r_proto:
                            try:
                                proto_ok = int(r_proto) == proto
                            except ValueError:
                                proto_ok = False
                        
                        if src_ok and dst_ok and proto_ok:
                            entry["type"] = "rule"
                            entry["alert"] = True
                            break
                
                # In-memory live buffer
                self.packet_log.append(entry)
                if len(self.packet_log) > 2000:
                    del self.packet_log[:len(self.packet_log) - 2000]
                
                # Persist
                self.save_log(entry)
        except Exception as e:
            print("[IDS packet_handler] error:", e)
    
    def start_sniffer(self):
        """Start the Scapy sniffer in a background thread"""
        if not SCAPY_AVAILABLE:
            print("[!] Scapy not available; live capture disabled.")
            return
        
        if getattr(self, "_sniffer_started", False):
            return
        
        def run_sniffer():
            try:
                print("[*] Starting background packet sniffer (filter='ip')...")
                # Requires admin/root privileges
                sniff(filter="ip", prn=self.packet_handler, store=0)
            except Exception as e:
                print("[!] Sniffer error:", e)
        
        self.sniffer_thread = threading.Thread(target=run_sniffer, daemon=True)
        self.sniffer_thread.start()
        self._sniffer_started = True

class NIDPSApp:
    """Main NIDPS Application with Authentication"""
    
    def __init__(self):
        self.app = Flask(__name__)
        self.app.secret_key = os.environ.get('SECRET_KEY') or 'nidps-secret-key-change-in-production'
        
        self.config = NIDPSConfig()
        self.user_manager = UserManager(self.config)
        self.auth_middleware = AuthMiddleware(self.user_manager)
        
        self.rule_manager = RuleManager(self.config)
        self.blacklist_manager = BlacklistManager(self.config)
        self.honeypot_manager = HoneypotManager(self.config)
        self.honeypot_log_manager = HoneypotLogManager(self.config)
        self.ids_log_manager = IDSLogManager(self.config)  # now starts sniffer
        
        self.setup_routes()
    
    def setup_routes(self):
        """Setup Flask routes with authentication"""
        
        # ==================== AUTH PAGES ====================
        @self.app.route("/login", methods=["GET", "POST"])
        @self.auth_middleware.require_unauth
        def login_page():
            if request.method == "POST":
                data = request.get_json() if request.is_json else request.form
                username = data.get("username", "").strip()
                password = data.get("password", "").strip()
                
                if not username or not password:
                    return jsonify({"success": False, "error": "Username and password required"}), 400
                
                result = self.user_manager.authenticate_user(username, password)
                if result["success"]:
                    session['user_id'] = result["user"]["id"]
                    session['username'] = result["user"]["username"]
                    session['last_activity'] = datetime.now().isoformat()
                    
                    if request.is_json:
                        return jsonify({"success": True, "redirect": url_for("index")})
                    return redirect(url_for("index"))
                else:
                    if request.is_json:
                        return jsonify(result), 401
                    return render_template("login.html", error=result["error"])
            
            return render_template("login.html")
        
        @self.app.route("/signup", methods=["GET", "POST"])
        @self.auth_middleware.require_unauth
        def signup_page():
            if request.method == "POST":
                data = request.get_json() if request.is_json else request.form
                username = data.get("username", "").strip()
                password = data.get("password", "").strip()
                email = data.get("email", "").strip()
                confirm_password = data.get("confirm_password", "").strip()
                
                # Validation
                if not username or not password:
                    error = "Username and password required"
                    if request.is_json:
                        return jsonify({"success": False, "error": error}), 400
                    return render_template("signup.html", error=error)
                
                if password != confirm_password:
                    error = "Passwords do not match"
                    if request.is_json:
                        return jsonify({"success": False, "error": error}), 400
                    return render_template("signup.html", error=error)
                
                if len(password) < 6:
                    error = "Password must be at least 6 characters"
                    if request.is_json:
                        return jsonify({"success": False, "error": error}), 400
                    return render_template("signup.html", error=error)
                
                result = self.user_manager.create_user(username, password, email)
                if result["success"]:
                    if request.is_json:
                        return jsonify({"success": True, "redirect": url_for("login_page")})
                    return redirect(url_for("login_page"))
                else:
                    if request.is_json:
                        return jsonify(result), 400
                    return render_template("signup.html", error=result["error"])
            
            return render_template("signup.html")
        
        @self.app.route("/logout")
        def logout():
            session.clear()
            return redirect(url_for("login_page"))
        
        @self.app.route("/profile")
        @self.auth_middleware.require_auth
        def profile_page():
            user = self.user_manager.get_user_by_id(session['user_id'])
            return render_template("profile.html", user=user, username=session.get('username'))
        
        # ==================== PROTECTED PAGES ====================
        @self.app.route("/")
        @self.auth_middleware.require_auth
        def index():
            return render_template("index.html", 
                                 ml_enabled=self.ids_log_manager.ml_enabled,
                                 username=session.get('username'))
        
        @self.app.get("/logs")
        @self.auth_middleware.require_auth
        def logs_page():
            return render_template("logs.html", 
                                 logs=self.ids_log_manager.load_logs(),
                                 username=session.get('username'))
        
        @self.app.get("/rules")
        @self.auth_middleware.require_auth
        def rules_page():
            return render_template("rules.html", 
                                 rules=self.rule_manager.load_rules(),
                                 username=session.get('username'))
        
        @self.app.get("/honeypot")
        @self.auth_middleware.require_auth
        def honeypot_page():
            status = self.honeypot_manager.get_status()
            return render_template("fullhoneypot.html",
                                 honeypot_running=status["running"],
                                 honeypot_port=status["port"],
                                 username=session.get('username'))
        
        # ==================== PROTECTED API ROUTES ====================
        
        # Rules API
        @self.app.get("/api/rules")
        @self.auth_middleware.require_auth
        def api_rules():
            return jsonify(self.rule_manager.load_rules())
        
        @self.app.post("/add-rule")
        @self.auth_middleware.require_auth
        def add_rule():
            data = request.get_json(silent=True) or {}
            if not data and request.form:
                data = request.form.to_dict()
            
            new_rule = {
                "src": (data.get("src") or "").strip(),
                "dst": (data.get("dst") or "").strip(),
                "protocol": (data.get("protocol") or "").strip(),
                "name": (data.get("name") or "Unnamed Rule").strip()
            }
            
            result = self.rule_manager.add_rule(new_rule)
            return jsonify(result)
        
        @self.app.post("/delete-rule")
        @self.auth_middleware.require_auth
        def delete_rule():
            data = request.get_json(silent=True) or {}
            if not data and request.form:
                data = request.form.to_dict()
            
            try:
                idx = int(data.get("index", -1))
            except (ValueError, TypeError):
                return jsonify({"status": "error", "error": "Invalid index"}), 400
            
            result = self.rule_manager.delete_rule(idx)
            if result["status"] == "error":
                return jsonify(result), 400
            return jsonify(result)
        
        # ML Toggle
        @self.app.post("/toggle-ml")
        @self.auth_middleware.require_auth
        def toggle_ml():
            self.ids_log_manager.ml_enabled = not self.ids_log_manager.ml_enabled
            return jsonify({"ml_enabled": self.ids_log_manager.ml_enabled})
        
        # IDS API
        @self.app.get("/api/stats")
        @self.auth_middleware.require_auth
        def stats_api():
            return jsonify(self.ids_log_manager.get_stats())
        
        @self.app.get("/api/alerts-per-hour")
        @self.auth_middleware.require_auth
        def alerts_per_hour_api():
            return jsonify(self.ids_log_manager.get_alerts_per_hour())
        
        @self.app.get("/api/recent-packets")
        @self.auth_middleware.require_auth
        def recent_packets():
            return jsonify(self.ids_log_manager.packet_log[-50:])
        
        @self.app.get("/api/live-packets")
        @self.auth_middleware.require_auth
        def live_packets():
            return jsonify(self.ids_log_manager.packet_log[-50:])
        
        # Honeypot API
        @self.app.post("/honeypot/control")
        @self.auth_middleware.require_auth
        def honeypot_control():
            data = request.get_json(silent=True) or {}
            if not data and request.form:
                data = request.form.to_dict()
            
            action = (data.get("action") or "").lower()
            port = data.get("port", self.honeypot_manager.status.get("port", 9999))
            
            if action in ("start", "on"):
                result, code = self.honeypot_manager.start(port)
                return jsonify(result), code
            elif action in ("stop", "off"):
                result, code = self.honeypot_manager.stop()
                return jsonify(result), code
            else:
                return jsonify({"status": "error", "error": "action must be 'start' or 'stop'"}), 400
        
        @self.app.get("/honeypot/status")
        @self.auth_middleware.require_auth
        def honeypot_status():
            return jsonify(self.honeypot_manager.get_status())
        
        @self.app.post("/honeypot/test")
        @self.auth_middleware.require_auth
        def honeypot_test():
            port = int((request.json or {}).get("port", self.honeypot_manager.status.get("port", 9999)))
            result = self.honeypot_manager.test_connection(port)
            if "error" in result:
                return jsonify(result), 500
            return jsonify(result)
        
        @self.app.post("/honeypot/blacklist")
        @self.auth_middleware.require_auth
        def honeypot_blacklist():
            ip = (request.json or {}).get("ip")
            if not ip:
                return jsonify({"status": "missing ip"}), 400
            
            result = self.blacklist_manager.add_to_blacklist(ip)
            return jsonify(result)
        
        @self.app.get("/api/honeypot-live")
        @self.auth_middleware.require_auth
        def api_honeypot_live():
            return jsonify(self.honeypot_log_manager.read_logs()[-20:])
        
        @self.app.get("/api/honeypot-logs")
        @self.auth_middleware.require_auth
        def api_honeypot_logs():
            start = request.args.get("start") or request.args.get("from")
            end = request.args.get("end") or request.args.get("to")
            return jsonify(self.honeypot_log_manager.get_filtered_logs(start, end))
        
        @self.app.get("/api/honeypot-alerts-per-hour")
        @self.auth_middleware.require_auth
        def honeypot_alerts_per_hour():
            rows = self.honeypot_log_manager.read_logs()
            hourly = defaultdict(int)
            
            for row in rows:
                try:
                    ts = datetime.strptime(row["timestamp"], "%Y-%m-%d %H:%M:%S")
                    hourly[ts.strftime("%Y-%m-%d %H:00")] += 1
                except Exception:
                    pass
            
            keys = sorted(hourly.keys())
            return jsonify({"labels": keys, "counts": [hourly[k] for k in keys]})
        
        # ==================== EXPORTS ====================
        @self.app.get("/export/logs.json")
        @self.auth_middleware.require_auth
        def export_ids_json():
            out = io.BytesIO()
            out.write(json.dumps(self.ids_log_manager.load_logs(), indent=2).encode())
            out.seek(0)
            return send_file(out, mimetype="application/json", as_attachment=True, download_name="ids_logs.json")
        
        @self.app.get("/export/logs.csv")
        @self.auth_middleware.require_auth
        def export_ids_csv():
            rows = self.ids_log_manager.load_logs()
            fields = ["timestamp", "src", "dst", "protocol", "payload_len", "alert", "type"]
            if rows:
                fields = list({k for r in rows for k in r.keys()})
            
            si = io.StringIO()
            cw = csv.DictWriter(si, fieldnames=fields)
            cw.writeheader()
            if rows:
                cw.writerows(rows)
            
            out = io.BytesIO()
            out.write(si.getvalue().encode())
            out.seek(0)
            return send_file(out, mimetype="text/csv", as_attachment=True, download_name="ids_logs.csv")
        
        @self.app.get("/export/honeypot.json")
        @self.auth_middleware.require_auth
        def export_hpot_json():
            rows = self.honeypot_log_manager.read_logs()
            out = io.BytesIO()
            out.write(json.dumps(rows, indent=2).encode())
            out.seek(0)
            return send_file(out, mimetype="application/json", as_attachment=True, download_name="honeypot_logs.json")
        
        @self.app.get("/export/honeypot.csv")
        @self.auth_middleware.require_auth
        def export_hpot_csv():
            rows = self.honeypot_log_manager.read_logs()
            fields = ["timestamp", "ip", "port", "request", "alert", "source"]
            
            si = io.StringIO()
            cw = csv.DictWriter(si, fieldnames=fields)
            cw.writeheader()
            if rows:
                cw.writerows(rows)
            
            out = io.BytesIO()
            out.write(si.getvalue().encode())
            out.seek(0)
            return send_file(out, mimetype="text/csv", as_attachment=True, download_name="honeypot_logs.csv")
        
        # ==================== DEBUG ====================
        @self.app.get("/debug/honeypot")
        @self.auth_middleware.require_auth
        def debug_honeypot():
            script_exists = self.honeypot_manager._honeypot_script() is not None
            log_file_exists = os.path.exists(self.config.HONEYPOT_LOG)
            
            log_contents = []
            if log_file_exists:
                try:
                    with open(self.config.HONEYPOT_LOG, 'r') as f:
                        content = f.read().strip()
                        if content:
                            logs = json.loads(content)
                            log_contents = logs[-5:]
                except Exception as e:
                    log_contents = [f"Error reading log: {str(e)}"]
            
            return jsonify({
                "script_exists": script_exists,
                "script_path": self.honeypot_manager._honeypot_script(),
                "log_file_exists": log_file_exists,
                "log_file_path": os.path.abspath(self.config.HONEYPOT_LOG),
                "process_running": self.honeypot_manager.process is not None and self.honeypot_manager.process.poll() is None,
                "status": self.honeypot_manager.status,
                "recent_logs": log_contents
            })
    
    def run(self, host='0.0.0.0', port=8855, debug=True):
        """Run the NIDPS application"""
        print(f"[*] Starting NIDPS on http://{host}:{port}")
        self.app.run(host=host, port=port, debug=debug)

# ==================== MAIN ====================
if __name__ == "__main__":
    nidps = NIDPSApp()
    nidps.run()
