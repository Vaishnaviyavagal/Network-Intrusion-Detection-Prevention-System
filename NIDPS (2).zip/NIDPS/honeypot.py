# honeypot.py — child process started by app.py (HTTP / SSH-tease / basic TCP)
import socket, threading, sys, json, time, os
from datetime import datetime
from contextlib import closing
from pathlib import Path

BIND_ADDR = "0.0.0.0"

def ensure_json_array(path: Path):
    if not path.exists():
        path.write_text("[]", encoding="utf-8")
        return
    try:
        raw = path.read_text(encoding="utf-8").strip()
        if not raw:
            path.write_text("[]", encoding="utf-8")
        else:
            json.loads(raw)
    except Exception:
        path.write_text("[]", encoding="utf-8")

def append_row(path: Path, row: dict, keep_last=5000):
    ensure_json_array(path)
    try:
        arr = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(arr, list): 
            arr = []
    except Exception:
        arr = []
    
    arr.append(row)
    
    if keep_last and len(arr) > keep_last: 
        arr = arr[-keep_last:]
    
    # Atomic write to prevent corruption
    tmp_path = Path(f"{path}.{int(time.time() * 1000)}.tmp")
    try:
        tmp_path.write_text(json.dumps(arr, indent=2), encoding="utf-8")
        tmp_path.replace(path)
    except Exception as e:
        print(f"[!] Failed to write log: {e}")
        try:
            tmp_path.unlink(missing_ok=True)
        except:
            pass

def log_evt(path: Path, ip: str, port: int, req: str, note=""):
    try:
        append_row(path, {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "ip": ip, 
            "port": port, 
            "request": (req or "")[:2000],
            "alert": True, 
            "source": "honeypot", 
            "note": note
        })
        print(f"[Honeypot] Connection from {ip}:{port} - {note}")
    except Exception as e:
        print(f"[!] Failed to log event: {e}")

def handle_ssh(cs: socket.socket, ip: str, port: int, path: Path):
    """Handle SSH connection attempts"""
    try:
        cs.sendall(b"SSH-2.0-OpenSSH_7.6p1 Ubuntu-4ubuntu0.3\r\n")
        log_evt(path, ip, port, "", note="ssh_tease_banner")
        
        # Wait for client key exchange
        try:
            cs.settimeout(5.0)
            client_data = cs.recv(1024)
            if client_data:
                log_evt(path, ip, port, client_data.decode(errors="replace"), note="ssh_client_key_exchange")
        except socket.timeout:
            pass
            
    except Exception as e:
        log_evt(path, ip, port, "", note=f"ssh_error:{e}")
    finally:
        try:
            cs.close()
        except:
            pass

def handle_http(cs: socket.socket, ip: str, port: int, path: Path, request_data: str):
    """Handle HTTP requests"""
    try:
        log_evt(path, ip, port, request_data, note="http_request")
        
        # Simple HTTP response
        body = b"""<html>
<head><title>Welcome</title></head>
<body>
    <h1>Welcome to Our Server</h1>
    <p>This is a test page</p>
</body>
</html>"""
        
        response = (
            b"HTTP/1.1 200 OK\r\n"
            b"Server: nginx/1.18.0\r\n"
            b"Content-Type: text/html; charset=UTF-8\r\n"
            b"Content-Length: " + str(len(body)).encode() + b"\r\n"
            b"Connection: close\r\n\r\n" + body
        )
        
        cs.sendall(response)
        log_evt(path, ip, port, "HTTP 200 OK", note="http_response")
        
    except Exception as e:
        log_evt(path, ip, port, "", note=f"http_error:{e}")
    finally:
        try:
            cs.close()
        except:
            pass

def handle_generic_tcp(cs: socket.socket, ip: str, port: int, path: Path, data: bytes):
    """Handle generic TCP connections"""
    try:
        text = data.decode(errors="replace")
        log_evt(path, ip, port, text, note="generic_tcp_data")
        
        # Send a welcome banner
        banner = b"Welcome to TCP Service\r\n> "
        cs.sendall(banner)
        
        # Echo back some data
        if data:
            echo_msg = b"Echo: " + data[:100] + b"\r\n"
            cs.sendall(echo_msg)
            log_evt(path, ip, port, f"Echoed: {data[:100]!r}", note="tcp_echo")
            
    except Exception as e:
        log_evt(path, ip, port, "", note=f"tcp_error:{e}")
    finally:
        try:
            cs.close()
        except:
            pass

def handle_connection(cs: socket.socket, addr, port: int, path: Path):
    """Main connection handler"""
    ip = addr[0]
    cs.settimeout(10.0)  # Overall timeout
    
    try:
        # Receive initial data
        try:
            data = cs.recv(4096)
        except socket.timeout:
            data = b""
        except ConnectionResetError:
            data = b""
        
        if not data:
            log_evt(path, ip, port, "", note="empty_connection")
            cs.close()
            return
        
        text = data.decode(errors="replace")
        
        # Protocol detection and routing
        if text.startswith("SSH-") or "SSH" in text.upper():
            handle_ssh(cs, ip, port, path)
            
        elif text.startswith(("GET ", "POST ", "PUT ", "DELETE ", "HEAD ", "OPTIONS ")) or "HTTP/" in text.upper():
            handle_http(cs, ip, port, path, text)
            
        else:
            handle_generic_tcp(cs, ip, port, path, data)
            
    except Exception as e:
        log_evt(path, ip, port, "", note=f"handler_error:{type(e).__name__}:{e}")
    finally:
        try:
            cs.close()
        except:
            pass

def honeypot_server(port: int, path: Path):
    """Main honeypot server loop"""
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            s.bind((BIND_ADDR, port))
            s.listen(128)
            s.settimeout(1.0)  # Allow for graceful shutdown
            
            log_evt(path, "0.0.0.0", port, "", note="honeypot_started")
            print(f"[Honeypot] Listening on port {port}, logging to {path}")
            
            while True:
                try:
                    cs, addr = s.accept()
                    log_evt(path, addr[0], port, "", note="new_connection")
                    
                    # Handle connection in separate thread
                    thread = threading.Thread(
                        target=handle_connection, 
                        args=(cs, addr, port, path), 
                        daemon=True
                    )
                    thread.start()
                    
                except socket.timeout:
                    continue
                except OSError as e:
                    if "winerror" in str(e).lower() or "bad file descriptor" in str(e).lower():
                        break  # Socket closed
                    continue
                    
        except Exception as e:
            log_evt(path, "0.0.0.0", port, "", note=f"server_error:{e}")
            print(f"[!] Honeypot server error: {e}")
            raise

def main():
    if len(sys.argv) < 2:
        print("Usage: python honeypot.py <port> [log_path]")
        sys.exit(1)
        
    try:
        port = int(sys.argv[1])
    except ValueError:
        print("Error: Port must be a number")
        sys.exit(1)
    
    # Use provided log path or default
    if len(sys.argv) >= 3:
        log_path = Path(sys.argv[2])
    else:
        log_path = Path("logs/honeypot_log.json")
    
    # Ensure log directory exists
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"[Honeypot] Starting on port {port}, log: {log_path}")
    
    try:
        honeypot_server(port, log_path)
    except KeyboardInterrupt:
        print("\n[Honeypot] Shutting down...")
    except Exception as e:
        print(f"[Honeypot] Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()